--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2 (Debian 11.2-1.pgdg90+1)
-- Dumped by pg_dump version 11.2 (Debian 11.2-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: inspector_logins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inspector_logins (
    login_id integer NOT NULL,
    inspector_id integer,
    created_at timestamp without time zone,
    created_ip_address character varying,
    api_key character varying,
    last_seen_at timestamp without time zone,
    disabled_at timestamp without time zone
);


--
-- Name: inspector_logins_login_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inspector_logins_login_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inspector_logins_login_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inspector_logins_login_id_seq OWNED BY public.inspector_logins.login_id;


--
-- Name: inspectors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inspectors (
    inspector_id integer NOT NULL,
    email character varying,
    created_at timestamp without time zone,
    name text,
    login_type character varying,
    password_hash character varying,
    disabled_at timestamp without time zone,
    language_code character varying,
    phone_no character varying
);


--
-- Name: inspectors_inspector_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inspectors_inspector_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inspectors_inspector_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inspectors_inspector_id_seq OWNED BY public.inspectors.inspector_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying,
    created_at timestamp without time zone,
    is_admin boolean,
    name text,
    last_seen_at timestamp without time zone,
    login_type character varying,
    password_hash text,
    disabled_at timestamp without time zone,
    is_email_user boolean,
    phone character varying
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: users_login_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_login_history (
    user_login_id integer NOT NULL,
    created_at timestamp without time zone,
    user_id integer,
    login_type character varying,
    ip_address character varying,
    token_id character varying,
    platform character varying,
    email character varying,
    result character varying
);


--
-- Name: users_login_history_user_login_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_login_history_user_login_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_login_history_user_login_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_login_history_user_login_id_seq OWNED BY public.users_login_history.user_login_id;


--
-- Name: inspector_logins login_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspector_logins ALTER COLUMN login_id SET DEFAULT nextval('public.inspector_logins_login_id_seq'::regclass);


--
-- Name: inspectors inspector_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspectors ALTER COLUMN inspector_id SET DEFAULT nextval('public.inspectors_inspector_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: users_login_history user_login_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_login_history ALTER COLUMN user_login_id SET DEFAULT nextval('public.users_login_history_user_login_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
16982b5f1b89
\.


--
-- Data for Name: inspector_logins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inspector_logins (login_id, inspector_id, created_at, created_ip_address, api_key, last_seen_at, disabled_at) FROM stdin;
\.


--
-- Data for Name: inspectors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inspectors (inspector_id, email, created_at, name, login_type, password_hash, disabled_at, language_code, phone_no) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, created_at, is_admin, name, last_seen_at, login_type, password_hash, disabled_at, is_email_user, phone) FROM stdin;
1	thayden@corrosionone.com	2020-11-29 20:36:09.165696	t	Tom Hayden	2020-11-29 15:04:40.891003	azure	\N	\N	\N	\N
\.


--
-- Data for Name: users_login_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_login_history (user_login_id, created_at, user_id, login_type, ip_address, token_id, platform, email, result) FROM stdin;
1	2020-11-29 14:37:18.421842	1	azure	172.22.0.1	\N	\N	\N	\N
2	2020-11-29 14:40:48.062831	1	azure	172.22.0.1	\N	\N	\N	\N
3	2020-11-29 15:04:40.851497	1	azure	172.22.0.1	\N	\N	\N	\N
4	2020-11-29 18:25:01.303526	\N	azure	172.22.0.1	\N	\N	thayden@engineeringdirector.com	FAILURE
5	2020-11-29 18:25:28.57639	\N	azure	172.22.0.1	\N	\N	thayden@engineeringdirector.com	FAILURE
6	2020-11-29 18:33:51.235152	\N	azure	172.22.0.1	\N	\N	asdf@asdf.com	FAILURE
\.


--
-- Name: inspector_logins_login_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inspector_logins_login_id_seq', 1, false);


--
-- Name: inspectors_inspector_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inspectors_inspector_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: users_login_history_user_login_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_login_history_user_login_id_seq', 6, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: inspector_logins inspector_logins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspector_logins
    ADD CONSTRAINT inspector_logins_pkey PRIMARY KEY (login_id);


--
-- Name: inspectors inspectors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspectors
    ADD CONSTRAINT inspectors_pkey PRIMARY KEY (inspector_id);


--
-- Name: users_login_history users_login_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_login_history
    ADD CONSTRAINT users_login_history_pkey PRIMARY KEY (user_login_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_inspector_logins_api_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inspector_logins_api_key ON public.inspector_logins USING btree (api_key);


--
-- Name: ix_inspector_logins_disabled_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inspector_logins_disabled_at ON public.inspector_logins USING btree (disabled_at);


--
-- Name: ix_inspector_logins_inspector_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inspector_logins_inspector_id ON public.inspector_logins USING btree (inspector_id);


--
-- Name: ix_inspectors_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inspectors_email ON public.inspectors USING btree (email);


--
-- Name: ix_users_login_history_platform; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_login_history_platform ON public.users_login_history USING btree (platform);


--
-- Name: ix_users_login_history_token_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_login_history_token_id ON public.users_login_history USING btree (token_id);


--
-- Name: ix_users_login_history_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_login_history_user_id ON public.users_login_history USING btree (user_id);


--
-- Name: inspector_logins inspector_logins_inspector_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspector_logins
    ADD CONSTRAINT inspector_logins_inspector_id_fkey FOREIGN KEY (inspector_id) REFERENCES public.users(id);


--
-- Name: users_login_history users_login_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_login_history
    ADD CONSTRAINT users_login_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

